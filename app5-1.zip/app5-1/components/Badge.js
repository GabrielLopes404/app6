import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Colors, FontSizes, BorderRadius, Spacing, FontWeights } from '../constants/theme';

export default function Badge({ text, variant = 'success', size = 'small', style }) {
  const getBackgroundColor = () => {
    switch (variant) {
      case 'success': return Colors.success;
      case 'error': return Colors.error;
      case 'warning': return Colors.warning;
      case 'primary': return Colors.primary;
      case 'accent': return Colors.accent;
      case 'gray': return Colors.backgroundGray;
      default: return Colors.success;
    }
  };

  const getTextColor = () => {
    return variant === 'gray' ? Colors.textPrimary : Colors.textLight;
  };

  const getPadding = () => {
    return size === 'small' 
      ? { paddingHorizontal: Spacing.sm, paddingVertical: Spacing.xs }
      : { paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm };
  };

  return (
    <View style={[
      styles.badge,
      { backgroundColor: getBackgroundColor() },
      getPadding(),
      style
    ]}>
      <Text style={[
        styles.text,
        { color: getTextColor(), fontSize: size === 'small' ? FontSizes.xs : FontSizes.sm }
      ]}>
        {text}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    borderRadius: BorderRadius.sm,
    alignSelf: 'flex-start',
  },
  text: {
    fontWeight: FontWeights.semibold,
  },
});
