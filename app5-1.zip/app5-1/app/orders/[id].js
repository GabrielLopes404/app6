import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../../constants/theme';

const trackingSteps = [
  { id: 1, title: 'Pedido confirmado', time: '14:30', completed: true },
  { id: 2, title: 'Preparando pedido', time: '14:45', completed: true },
  { id: 3, title: 'Saiu para entrega', time: '15:20', completed: true },
  { id: 4, title: 'Entregue', time: '', completed: false },
];

export default function OrderDetailScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams();

  const order = {
    id,
    orderNumber: '#PG2024-0847',
    status: 'Saiu para entrega',
    statusColor: Colors.primary,
    date: '10 de Nov, 2024',
    time: '14:30',
    estimatedDelivery: '16:00 - 16:30',
    store: {
      name: 'Pet Shop Central',
      image: 'https://images.unsplash.com/photo-1601758228041-f3b2795255f1?w=200',
      phone: '(11) 98765-4321',
    },
    deliveryAddress: 'Rua das Flores, 123 - Centro\nSão Paulo, SP - 01234-567',
    items: [
      {
        id: '1',
        name: 'Ração Premium Golden 15kg',
        quantity: 1,
        price: 189.90,
        image: 'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=200',
      },
      {
        id: '2',
        name: 'Brinquedo Kong Classic',
        quantity: 2,
        price: 49.90,
        image: 'https://images.unsplash.com/photo-1535294435445-d7249524ef2e?w=200',
      },
    ],
    payment: 'Cartão de Crédito •••• 1234',
    subtotal: 289.70,
    deliveryFee: 10.00,
    total: 299.70,
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Detalhes do Pedido</Text>
        <TouchableOpacity>
          <Ionicons name="help-circle-outline" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.statusCard}>
          <View style={styles.statusHeader}>
            <View style={[styles.statusDot, { backgroundColor: order.statusColor }]} />
            <Text style={[styles.statusText, { color: order.statusColor }]}>
              {order.status}
            </Text>
          </View>
          <Text style={styles.orderNumber}>{order.orderNumber}</Text>
          <Text style={styles.orderDate}>{order.date} às {order.time}</Text>
          
          {order.estimatedDelivery && (
            <View style={styles.estimateBox}>
              <Ionicons name="time-outline" size={20} color={Colors.primary} />
              <View style={styles.estimateText}>
                <Text style={styles.estimateLabel}>Previsão de entrega</Text>
                <Text style={styles.estimateTime}>{order.estimatedDelivery}</Text>
              </View>
            </View>
          )}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Acompanhamento</Text>
          
          <View style={styles.trackingContainer}>
            {trackingSteps.map((step, index) => (
              <View key={step.id} style={styles.trackingStep}>
                <View style={styles.trackingIndicator}>
                  <View style={[
                    styles.trackingDot,
                    step.completed && styles.trackingDotCompleted
                  ]}>
                    {step.completed && (
                      <Ionicons name="checkmark" size={16} color={Colors.textLight} />
                    )}
                  </View>
                  {index < trackingSteps.length - 1 && (
                    <View style={[
                      styles.trackingLine,
                      step.completed && styles.trackingLineCompleted
                    ]} />
                  )}
                </View>
                
                <View style={styles.trackingContent}>
                  <Text style={[
                    styles.trackingTitle,
                    !step.completed && styles.trackingTitleInactive
                  ]}>
                    {step.title}
                  </Text>
                  {step.time && (
                    <Text style={styles.trackingTime}>{step.time}</Text>
                  )}
                </View>
              </View>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Loja</Text>
          
          <View style={styles.storeCard}>
            <Image
              source={{ uri: order.store.image }}
              style={styles.storeImage}
              resizeMode="cover"
            />
            <View style={styles.storeInfo}>
              <Text style={styles.storeName}>{order.store.name}</Text>
              <TouchableOpacity style={styles.phoneButton} activeOpacity={0.8}>
                <Ionicons name="call-outline" size={16} color={Colors.primary} />
                <Text style={styles.phoneText}>{order.store.phone}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Endereço de entrega</Text>
          <View style={styles.addressCard}>
            <Ionicons name="location" size={20} color={Colors.primary} />
            <Text style={styles.addressText}>{order.deliveryAddress}</Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Itens do pedido</Text>
          
          {order.items.map((item) => (
            <View key={item.id} style={styles.itemCard}>
              <Image
                source={{ uri: item.image }}
                style={styles.itemImage}
                resizeMode="cover"
              />
              <View style={styles.itemInfo}>
                <Text style={styles.itemName}>{item.name}</Text>
                <Text style={styles.itemQuantity}>Qtd: {item.quantity}</Text>
              </View>
              <Text style={styles.itemPrice}>
                R$ {(item.price * item.quantity).toFixed(2)}
              </Text>
            </View>
          ))}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Resumo do pagamento</Text>
          
          <View style={styles.summaryCard}>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Subtotal</Text>
              <Text style={styles.summaryValue}>R$ {order.subtotal.toFixed(2)}</Text>
            </View>
            
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Taxa de entrega</Text>
              <Text style={styles.summaryValue}>R$ {order.deliveryFee.toFixed(2)}</Text>
            </View>
            
            <View style={styles.summaryDivider} />
            
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabelTotal}>Total</Text>
              <Text style={styles.summaryValueTotal}>R$ {order.total.toFixed(2)}</Text>
            </View>
            
            <View style={styles.paymentMethod}>
              <Ionicons name="card-outline" size={18} color={Colors.textSecondary} />
              <Text style={styles.paymentText}>{order.payment}</Text>
            </View>
          </View>
        </View>

        <TouchableOpacity style={styles.helpButton} activeOpacity={0.8}>
          <Ionicons name="help-circle" size={20} color={Colors.primary} />
          <Text style={styles.helpText}>Precisa de ajuda?</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    backgroundColor: Colors.backgroundLight,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  headerTitle: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: Spacing.lg,
  },
  statusCard: {
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    marginBottom: Spacing.lg,
    ...Shadows.medium,
  },
  statusHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  statusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  statusText: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.semibold,
  },
  orderNumber: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
    marginBottom: 4,
  },
  orderDate: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
  },
  estimateBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.primaryLight,
    borderRadius: BorderRadius.md,
    padding: Spacing.md,
    marginTop: Spacing.md,
    gap: Spacing.sm,
  },
  estimateText: {
    flex: 1,
  },
  estimateLabel: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
  },
  estimateTime: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.primary,
  },
  section: {
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginBottom: Spacing.md,
  },
  trackingContainer: {
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    ...Shadows.small,
  },
  trackingStep: {
    flexDirection: 'row',
    gap: Spacing.md,
  },
  trackingIndicator: {
    alignItems: 'center',
  },
  trackingDot: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: Colors.background,
  },
  trackingDotCompleted: {
    backgroundColor: Colors.primary,
  },
  trackingLine: {
    width: 2,
    flex: 1,
    backgroundColor: Colors.border,
    marginVertical: 4,
  },
  trackingLineCompleted: {
    backgroundColor: Colors.primary,
  },
  trackingContent: {
    flex: 1,
    paddingVertical: Spacing.xs,
    paddingBottom: Spacing.lg,
  },
  trackingTitle: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  trackingTitleInactive: {
    color: Colors.textSecondary,
  },
  trackingTime: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
  },
  storeCard: {
    flexDirection: 'row',
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
    gap: Spacing.md,
    ...Shadows.small,
  },
  storeImage: {
    width: 60,
    height: 60,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.backgroundGray,
  },
  storeInfo: {
    flex: 1,
    justifyContent: 'center',
  },
  storeName: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
    marginBottom: Spacing.xs,
  },
  phoneButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  phoneText: {
    fontSize: FontSizes.sm,
    color: Colors.primary,
    fontWeight: FontWeights.medium,
  },
  addressCard: {
    flexDirection: 'row',
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    gap: Spacing.md,
    ...Shadows.small,
  },
  addressText: {
    flex: 1,
    fontSize: FontSizes.md,
    color: Colors.textPrimary,
    lineHeight: 20,
  },
  itemCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
    marginBottom: Spacing.sm,
    gap: Spacing.md,
    ...Shadows.small,
  },
  itemImage: {
    width: 50,
    height: 50,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.backgroundGray,
  },
  itemInfo: {
    flex: 1,
  },
  itemName: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.medium,
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  itemQuantity: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
  },
  itemPrice: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
  },
  summaryCard: {
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    ...Shadows.small,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.sm,
  },
  summaryLabel: {
    fontSize: FontSizes.md,
    color: Colors.textSecondary,
  },
  summaryValue: {
    fontSize: FontSizes.md,
    color: Colors.textPrimary,
  },
  summaryDivider: {
    height: 1,
    backgroundColor: Colors.border,
    marginVertical: Spacing.md,
  },
  summaryLabelTotal: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
  },
  summaryValueTotal: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.bold,
    color: Colors.primary,
  },
  paymentMethod: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    marginTop: Spacing.md,
    paddingTop: Spacing.md,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  paymentText: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
  },
  helpButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.primaryLight,
    borderRadius: BorderRadius.lg,
    paddingVertical: Spacing.lg,
    gap: Spacing.sm,
    marginTop: Spacing.md,
  },
  helpText: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.primary,
  },
});
