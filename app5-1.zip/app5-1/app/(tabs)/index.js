import React, { useState } from 'react';
import { View, StyleSheet, FlatList, RefreshControl } from 'react-native';
import Animated, {
  useAnimatedScrollHandler,
  useSharedValue,
} from 'react-native-reanimated';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Colors, Spacing } from '../../constants/theme';

import HeaderLocation from '../../components/HeaderLocation';
import SearchBarPremium from '../../components/SearchBarPremium';
import SmartCarousel from '../../components/SmartCarousel';
import CategoryIconRow from '../../components/CategoryIconRow';
import HorizontalStoreHighlights from '../../components/HorizontalStoreHighlights';
import StickyFilterBar from '../../components/StickyFilterBar';
import StoreListItem from '../../components/StoreListItem';
import ToastManager, { showToast } from '../../components/ToastManager';
import SkeletonLoader from '../../components/SkeletonLoader';

import { banners, categories, stores } from '../../constants/mockData';

const AnimatedFlatList = Animated.createAnimatedComponent(FlatList);

export default function HomeScreen() {
  const router = useRouter();
  
  const [location, setLocation] = useState('Rua das Flores, 123 - Centro');
  const [activeFilter, setActiveFilter] = useState('all');
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(false);
  
  const scrollY = useSharedValue(0);

  const scrollHandler = useAnimatedScrollHandler({
    onScroll: (event) => {
      scrollY.value = event.contentOffset.y;
    },
  });

  const forYouStores = stores.filter(s => s.isFeatured).slice(0, 5);
  const newStores = stores.filter(s => s.rating >= 4.8);
  const filteredStores = filterStores(stores, activeFilter);

  const carouselItems = banners.map(banner => ({
    ...banner,
    badge: banner.action === 'shop' ? '🛍️ Compre agora' : '📅 Agende',
  }));

  function filterStores(storeList, filter) {
    switch (filter) {
      case 'fast':
        return storeList.filter(s => s.deliveryTime && parseInt(s.deliveryTime) < 40);
      case 'nearby':
        return storeList.filter(s => s.distance < 2);
      case 'discount':
        return storeList.filter(s => s.discount);
      case 'new':
        return storeList.filter(s => s.rating >= 4.8);
      case 'rated':
        return storeList.sort((a, b) => b.rating - a.rating);
      case 'open':
        return storeList.filter(s => s.isOpen);
      default:
        return storeList;
    }
  }

  const handleLocationPress = () => {
    showToast('Selecione sua localização', 'info');
  };

  const handleNotificationPress = () => {
    showToast('Você tem 3 novas notificações', 'info');
  };

  const handleSearch = (query) => {
    if (query) {
      showToast(`Buscando por "${query}"...`, 'info');
      router.push('/search');
    }
  };

  const handleFilterChange = (filter) => {
    setActiveFilter(filter);
  };

  const handleCarouselItemPress = (item) => {
    showToast(`Promoção: ${item.title}`, 'success');
  };

  const handleCategoryPress = (category) => {
    showToast(`Categoria: ${category.name}`, 'info');
  };

  const handleStorePress = (store) => {
    router.push(`/store/${store.id}`);
  };

  const handleSeeAll = () => {
    showToast('Ver todas as lojas', 'info');
  };

  const onRefresh = () => {
    setRefreshing(true);
    setTimeout(() => {
      setRefreshing(false);
      showToast('Atualizado com sucesso!', 'success');
    }, 1500);
  };

  const renderHeader = () => (
    <>
      <SearchBarPremium
        onSearch={handleSearch}
        placeholder="Buscar lojas, produtos, serviços..."
      />

      <StickyFilterBar
        activeFilter={activeFilter}
        onFilterChange={handleFilterChange}
        scrollY={scrollY}
      />

      <SmartCarousel
        items={carouselItems}
        onItemPress={handleCarouselItemPress}
        autoPlay={true}
        autoPlayInterval={5000}
      />

      <CategoryIconRow
        categories={categories}
        onCategoryPress={handleCategoryPress}
      />

      <HorizontalStoreHighlights
        title="Para você"
        subtitle="Selecionados especialmente"
        stores={forYouStores}
        onStorePress={handleStorePress}
        onSeeAll={handleSeeAll}
      />

      <HorizontalStoreHighlights
        title="Novidades"
        subtitle="Recém chegados na plataforma"
        stores={newStores}
        onStorePress={handleStorePress}
        onSeeAll={handleSeeAll}
      />
    </>
  );

  const renderStore = ({ item, index }) => (
    <StoreListItem 
      store={item} 
      onPress={handleStorePress}
    />
  );

  const renderFooter = () => {
    if (!loading) return <View style={styles.bottomSpacing} />;
    return (
      <View style={styles.loadingFooter}>
        <SkeletonLoader width="90%" height={120} style={styles.skeletonItem} />
        <SkeletonLoader width="90%" height={120} style={styles.skeletonItem} />
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <HeaderLocation
        location={location}
        onLocationPress={handleLocationPress}
        onNotificationPress={handleNotificationPress}
        scrollY={scrollY}
        hasNotification={true}
      />

      <AnimatedFlatList
        data={filteredStores}
        renderItem={renderStore}
        keyExtractor={(item) => item.id}
        ListHeaderComponent={renderHeader}
        ListFooterComponent={renderFooter}
        showsVerticalScrollIndicator={false}
        onScroll={scrollHandler}
        scrollEventThrottle={16}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={Colors.primary}
            colors={[Colors.primary]}
          />
        }
        contentContainerStyle={styles.scrollContent}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={10}
        removeClippedSubviews={true}
        getItemLayout={(data, index) => ({
          length: 136,
          offset: 136 * index,
          index,
        })}
      />

      <ToastManager />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContent: {
    paddingBottom: Spacing.massive * 2,
  },
  categorySection: {
    marginBottom: Spacing.md,
  },
  bottomSpacing: {
    height: Spacing.xxxl,
  },
  loadingFooter: {
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
  },
  skeletonItem: {
    marginBottom: Spacing.md,
    borderRadius: 12,
  },
});
